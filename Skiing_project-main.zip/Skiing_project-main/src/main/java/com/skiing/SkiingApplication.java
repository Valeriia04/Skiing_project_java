package com.skiing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkiingApplication {
	public static void main(String[] args) {
		SpringApplication.run(SkiingApplication.class, args);
	}
}
