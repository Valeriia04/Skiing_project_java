package com.skiing.models.enums;

public enum UserRole {
    CLIENT, MANAGER, COURIER
}
