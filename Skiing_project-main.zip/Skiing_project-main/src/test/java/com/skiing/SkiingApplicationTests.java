package com.skiing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkiingApplicationTests {

	@Test
	void contextLoads() {
	}

}
